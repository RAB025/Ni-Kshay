document.addEventListener("DOMContentLoaded", () => {
    const MASTER_PIN = "admin2026";

    const gateCard = document.getElementById("gateCard");
    const adminDashboard = document.getElementById("adminDashboard");
    const adminPinInput = document.getElementById("adminPinInput");
    const btnUnlockAdmin = document.getElementById("btnUnlockAdmin");
    const gateError = document.getElementById("gateError");
    const btnLockAdmin = document.getElementById("btnLockAdmin");

    const targetUser = document.getElementById("targetUser");
    const targetPassword = document.getElementById("targetPassword");
    const presetButtons = document.querySelectorAll(".btn-preset");
    const customExpiryDate = document.getElementById("customExpiryDate");
    const btnGenerate = document.getElementById("btnGenerate");

    const resultBox = document.getElementById("resultBox");
    const resUser = document.getElementById("resUser");
    const resExpires = document.getElementById("resExpires");
    const tokenOutput = document.getElementById("tokenOutput");
    const btnCopyToken = document.getElementById("btnCopyToken");
    const btnShareWa = document.getElementById("btnShareWa");

    const verifyInput = document.getElementById("verifyInput");
    const btnVerify = document.getElementById("btnVerify");
    const verifyResult = document.getElementById("verifyResult");

    let selectedDays = 30;

    // Check if session is already unlocked
    if (sessionStorage.getItem("nikshay_admin_unlocked") === "true") {
        gateCard.style.display = "none";
        adminDashboard.style.display = "block";
    }

    btnUnlockAdmin.addEventListener("click", () => {
        const pin = (adminPinInput.value || "").trim();
        if (pin === MASTER_PIN) {
            sessionStorage.setItem("nikshay_admin_unlocked", "true");
            gateCard.style.display = "none";
            adminDashboard.style.display = "block";
        } else {
            gateError.style.display = "block";
            adminPinInput.focus();
        }
    });

    adminPinInput.addEventListener("keydown", (e) => {
        if (e.key === "Enter") btnUnlockAdmin.click();
    });

    btnLockAdmin.addEventListener("click", (e) => {
        e.preventDefault();
        sessionStorage.removeItem("nikshay_admin_unlocked");
        adminDashboard.style.display = "none";
        gateCard.style.display = "block";
        adminPinInput.value = "";
    });

    // Preset duration buttons
    presetButtons.forEach(btn => {
        btn.addEventListener("click", () => {
            presetButtons.forEach(b => b.classList.remove("active"));
            btn.classList.add("active");
            selectedDays = parseInt(btn.getAttribute("data-days"), 10) || 30;
            customExpiryDate.value = "";
        });
    });

    customExpiryDate.addEventListener("change", () => {
        if (customExpiryDate.value) {
            presetButtons.forEach(b => b.classList.remove("active"));
        }
    });

    // Generate Token
    btnGenerate.addEventListener("click", () => {
        const username = (targetUser.value || "").trim();
        const password = (targetPassword.value || "").trim();

        if (!username) {
            alert("Please enter the user's Login ID / Username.");
            targetUser.focus();
            return;
        }

        let expiresAt;
        if (customExpiryDate.value) {
            expiresAt = new Date(customExpiryDate.value).getTime();
            if (isNaN(expiresAt) || expiresAt <= Date.now()) {
                alert("Please select a future expiration date and time.");
                return;
            }
        } else {
            expiresAt = Date.now() + (selectedDays * 24 * 60 * 60 * 1000);
        }

        try {
            const token = NikshayAuth.generateToken({
                username,
                password,
                expiresAt
            });

            const expDate = new Date(expiresAt);
            const expFormatted = expDate.toLocaleDateString("en-IN", {
                day: "numeric",
                month: "short",
                year: "numeric",
                hour: "2-digit",
                minute: "2-digit"
            });

            resUser.innerText = username;
            resExpires.innerText = expFormatted;
            tokenOutput.innerText = token;
            resultBox.style.display = "block";

            // Format WhatsApp share message
            const waMsg = `Hello,\nHere is your *Ni-Kshay Automation* access token:\n\n👤 *Login ID:* ${username}\n📅 *Valid Until:* ${expFormatted}\n\n🔑 *Token:* (Copy & paste into app)\n${token}\n\n_Keep this token safe. Contact admin when renewal is needed._`;
            btnShareWa.href = `https://wa.me/?text=${encodeURIComponent(waMsg)}`;

            tokenOutput.scrollIntoView({ behavior: "smooth" });
        } catch (err) {
            alert("Token generation error: " + (err?.message || err));
        }
    });

    btnCopyToken.addEventListener("click", async () => {
        const token = tokenOutput.innerText;
        if (token) {
            try {
                await navigator.clipboard.writeText(token);
                btnCopyToken.innerText = "✅ Copied!";
                setTimeout(() => {
                    btnCopyToken.innerText = "📋 Copy Token";
                }, 2000);
            } catch (_) {
                alert("Failed to copy automatically. Please select and copy manually.");
            }
        }
    });

    // Verify & Inspect Token
    btnVerify.addEventListener("click", () => {
        const raw = (verifyInput.value || "").trim();
        if (!raw) {
            verifyResult.style.display = "none";
            return;
        }

        const decoded = NikshayAuth.decodeToken(raw);
        if (!decoded || !decoded.payload) {
            verifyResult.innerHTML = `<span style="color:#ff7b72;">❌ Invalid token format or corrupted string.</span>`;
            verifyResult.style.display = "block";
            return;
        }

        const p = decoded.payload;
        const testUser = p.u || "";
        const verify = NikshayAuth.verifyToken(raw, testUser);

        const expDate = new Date(p.exp);
        const expStr = expDate.toLocaleDateString("en-IN", {
            day: "numeric",
            month: "short",
            year: "numeric",
            hour: "2-digit",
            minute: "2-digit"
        });

        const now = Date.now();
        const isExp = now > p.exp;
        const daysLeft = Math.ceil((p.exp - now) / (1000 * 60 * 60 * 24));

        let html = `
            <div style="background:#090d12; padding:12px; border-radius:6px; border:1px solid #30363d;">
                <div>User ID: <strong style="color:#7ee787;">${p.u}</strong></div>
                <div>Requires Password: <strong>${p.p ? "Yes" : "No"}</strong></div>
                <div>Expires: <strong>${expStr}</strong></div>
                <div>Status: ${isExp
                    ? `<strong style="color:#ff7b72;">Expired (${Math.abs(daysLeft)} days ago)</strong>`
                    : `<strong style="color:#3fb950;">Active (${daysLeft} days remaining)</strong>`
                }</div>
                <div style="margin-top:6px; font-size:11px; color:#8b949e;">Signature: ${verify.valid ? "✅ Valid HMAC-SHA256" : "❌ Invalid / Altered"}</div>
            </div>
        `;

        verifyResult.innerHTML = html;
        verifyResult.style.display = "block";
    });
});
