document.addEventListener("DOMContentLoaded", async () => {
    const statusBanner = document.getElementById("statusBanner");
    const activeSessionBox = document.getElementById("activeSessionBox");
    const activeUser = document.getElementById("activeUser");
    const activeExpires = document.getElementById("activeExpires");
    const activeDays = document.getElementById("activeDays");
    const btnContinue = document.getElementById("btnContinue");
    const tokenForm = document.getElementById("tokenForm");
    const loginIdInput = document.getElementById("loginId");
    const loginPasswordInput = document.getElementById("loginPassword");
    const accessTokenInput = document.getElementById("accessToken");
    const btnPaste = document.getElementById("btnPaste");
    const btnRequestWhatsapp = document.getElementById("btnRequestWhatsapp");

    function showBanner(message, type = "error") {
        statusBanner.className = `status-banner ${type}`;
        statusBanner.innerText = message;
    }

    function updateWhatsappLink() {
        const user = (loginIdInput.value || "").trim();
        const baseMsg = user
            ? `Hello Admin, please provide a Ni-Kshay Automation token for Login ID: ${user}`
            : `Hello Admin, please provide a Ni-Kshay Automation access token.`;
        btnRequestWhatsapp.href = `https://wa.me/917006444824?text=${encodeURIComponent(baseMsg)}`;
    }

    loginIdInput.addEventListener("input", updateWhatsappLink);
    updateWhatsappLink();

    // Check query params
    const params = new URLSearchParams(location.search);
    const reason = params.get("reason");
    const queryUser = params.get("user");

    if (queryUser) {
        loginIdInput.value = queryUser;
        updateWhatsappLink();
    }

    if (reason === "expired") {
        showBanner("Your access token has expired. Please enter the new token from your Admin to continue.", "error");
    } else if (reason === "missing") {
        showBanner("Please activate your app with a valid Login ID and Access Token.", "info");
    }

    // Check existing session
    const session = await NikshayAuth.getAuthSession();
    if (session.isAuthenticated) {
        activeUser.innerText = session.user;
        const dateStr = session.expiresDate
            ? session.expiresDate.toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "numeric" })
            : "";
        activeExpires.innerText = dateStr;
        activeDays.innerText = `${session.remainingDays} days`;
        activeSessionBox.style.display = "block";
        loginIdInput.value = session.user;
        updateWhatsappLink();
    } else if (session.expired) {
        showBanner(`Your access for "${session.user}" expired on ${session.expiresDate?.toLocaleDateString("en-IN")}. Enter renewed token below.`, "error");
        loginIdInput.value = session.user || "";
        updateWhatsappLink();
    }

    btnContinue?.addEventListener("click", () => {
        location.href = "option.html";
    });

    btnPaste?.addEventListener("click", async () => {
        try {
            if (navigator.clipboard && navigator.clipboard.readText) {
                const text = await navigator.clipboard.readText();
                if (text) {
                    accessTokenInput.value = text.trim();
                    accessTokenInput.focus();
                }
            } else {
                accessTokenInput.focus();
                accessTokenInput.select();
                alert("Please paste your token directly into the box.");
            }
        } catch (_) {
            accessTokenInput.focus();
        }
    });

    tokenForm.addEventListener("submit", async (e) => {
        e.preventDefault();

        const username = loginIdInput.value.trim();
        const password = loginPasswordInput.value.trim();
        const token = accessTokenInput.value.trim();

        if (!username) {
            showBanner("Please enter your Login ID.", "error");
            loginIdInput.focus();
            return;
        }

        if (!token) {
            showBanner("Please enter or paste your Access Token.", "error");
            accessTokenInput.focus();
            return;
        }

        const verify = NikshayAuth.verifyToken(token, username, password);

        if (!verify.valid) {
            showBanner(verify.error || "Token verification failed.", "error");
            return;
        }

        // Save session
        try {
            await NikshayAuth.saveAuthSession({
                username,
                token,
                password,
                expiresAt: verify.payload.exp
            });

            const expStr = verify.expiresDate.toLocaleDateString("en-IN", {
                day: "numeric",
                month: "short",
                year: "numeric"
            });

            showBanner(`Access Granted! Token is valid for ${verify.remainingDays} days (until ${expStr}). Redirecting...`, "success");

            setTimeout(() => {
                location.href = "option.html";
            }, 1200);
        } catch (err) {
            showBanner(`Error saving token: ${err?.message || err}`, "error");
        }
    });
});
