(function (global) {
    function cleanStr(s) {
        return (s || "").toLowerCase().replace(/[^a-z0-9]/g, "");
    }

    const COLLECTION_SITE_KEYS = [
        "COLLECTION SITE",
        "Collection Site",
        "Collection site",
        "collection site",
        "COLLECTIONSITE",
        "CollectionSite",
        "COLLECTION_SITE",
        "collection_site",
        "Sample Collection Site",
        "SAMPLE COLLECTION SITE",
        "Sample Collection site",
        "sample collection site",
        "Collection Facility",
        "COLLECTION FACILITY",
        "Collection Center",
        "COLLECTION CENTER",
        "Collection Centre",
        "COLLECTION CENTRE",
        "Sample Site",
        "SAMPLE SITE",
        "Site",
        "SITE",
        "site",
        "Site Name",
        "SITE NAME",
        "Facility",
        "FACILITY",
        "Health Facility",
        "HEALTH FACILITY"
    ];

    function getRowVal(row, ...keys) {
        if (!row) return "";
        for (const key of keys) {
            if (row[key] !== undefined && row[key] !== null && String(row[key]).trim() !== "") {
                return String(row[key]).trim();
            }
            const found = Object.keys(row).find(k => k.trim().toLowerCase() === key.toLowerCase());
            if (found && row[found] !== undefined && row[found] !== null && String(row[found]).trim() !== "") {
                return String(row[found]).trim();
            }
        }
        for (const key of keys) {
            const cleanKey = cleanStr(key);
            if (!cleanKey) continue;
            const found = Object.keys(row).find(k => cleanStr(k) === cleanKey);
            if (found && row[found] !== undefined && row[found] !== null && String(row[found]).trim() !== "") {
                return String(row[found]).trim();
            }
        }
        for (const key of keys) {
            const cleanKey = cleanStr(key);
            if (cleanKey.length >= 4) {
                const found = Object.keys(row).find(k => {
                    const cK = cleanStr(k);
                    return cK && (cK.includes(cleanKey) || cleanKey.includes(cK));
                });
                if (found && row[found] !== undefined && row[found] !== null && String(row[found]).trim() !== "") {
                    return String(row[found]).trim();
                }
            }
        }
        return "";
    }

    function parseCSVLine(text) {
        const p = [];
        let cur = "";
        let inQuotes = false;
        for (let i = 0; i < text.length; i++) {
            const c = text[i];
            if (c === '"') {
                if (inQuotes && text[i + 1] === '"') {
                    cur += '"';
                    i++;
                } else {
                    inQuotes = !inQuotes;
                }
            } else if (c === ',' && !inQuotes) {
                p.push(cur.trim());
                cur = "";
            } else {
                cur += c;
            }
        }
        p.push(cur.trim());
        return p;
    }

    async function csvToSheet(file) {
        const text = await file.text();
        const array = text.split(/\r?\n/).filter(line => line.trim().length > 0);
        if (array.length === 0) return [];

        const titleArray = parseCSVLine(array[0]);
        array.shift();

        const tmp = [];
        for (let index = 0; index < array.length; index++) {
            const json = {};
            const values = parseCSVLine(array[index]);
            for (let index2 = 0; index2 < titleArray.length; index2++) {
                const title = titleArray[index2];
                if (title) {
                    json[title] = values[index2] !== undefined ? values[index2].trim() : "";
                }
            }
            tmp.push(json);
        }
        return tmp;
    }

    function excelToSheet(file) {
        return new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.onload = function (e) {
                try {
                    const data = new Uint8Array(e.target.result);
                    const workbook = XLSX.read(data, { type: "array" });
                    const result = {};
                    workbook.SheetNames.forEach(function (sheetName) {
                        const roa = XLSX.utils.sheet_to_row_object_array(workbook.Sheets[sheetName]);
                        if (roa.length > 0) {
                            result[sheetName] = roa;
                        }
                    });

                    const firstKey = Object.keys(result)[0];
                    const rawSheet = firstKey ? result[firstKey] : [];
                    const sheet = rawSheet.map(row => {
                        const cleanRow = {};
                        for (const key in row) {
                            const cleanKey = key.trim();
                            cleanRow[cleanKey] = typeof row[key] === "string" ? row[key].trim() : row[key];
                        }
                        return cleanRow;
                    });
                    resolve(sheet);
                } catch (err) {
                    reject(err);
                }
            };
            reader.onerror = () => reject(reader.error || new Error("Failed to read file"));
            reader.readAsArrayBuffer(file);
        });
    }

    async function parseSpreadsheetFile(file) {
        const filename = file.name || "";
        const dotIdx = filename.lastIndexOf(".");
        const extension = dotIdx >= 0 ? filename.substring(dotIdx).toUpperCase() : "";
        if (extension === ".CSV") {
            return await csvToSheet(file);
        }
        return await excelToSheet(file);
    }

    function showLoading(show = true) {
        const el = document.getElementById("loading");
        if (el) {
            el.style.display = show ? "flex" : "none";
        }
    }

    function initProfileAndVersion() {
        const emailEl = document.getElementById("email");
        const verEl = document.getElementById("version");

        let versionLabel = "V2.2.0";
        try {
            if (typeof chrome !== "undefined" && chrome.runtime && chrome.runtime.getManifest) {
                const manifest = chrome.runtime.getManifest();
                if (manifest) {
                    versionLabel = manifest.version_name || ("V" + manifest.version);
                }
            } else if (global.AndroidBridge && global.AndroidBridge.getAppVersion) {
                versionLabel = global.AndroidBridge.getAppVersion() || versionLabel;
            }
        } catch (e) {}
        if (verEl) verEl.innerText = versionLabel;

        if (global.NikshayAuth && global.NikshayAuth.getAuthSession) {
            global.NikshayAuth.getAuthSession().then(session => {
                if (session && session.isAuthenticated) {
                    global.NikshayAuth.renderHeaderBadge(session);
                } else if (emailEl) {
                    emailEl.innerText = "Activation Required";
                }
            });
            return;
        }

        if (emailEl) emailEl.innerText = "Active";
    }

    function exportTableToCSV(tableId, filename = "data.csv") {
        const table = document.getElementById(tableId);
        if (!table) {
            console.error(`Table with ID '${tableId}' not found.`);
            return;
        }

        const rows = table.querySelectorAll("tr");
        const csv = [];

        for (const row of rows) {
            const cells = row.querySelectorAll("th, td");
            const rowText = Array.from(cells).map(cell => `"${cell.innerText.replace(/"/g, '""')}"`);
            csv.push(rowText.join(","));
        }

        const csvContent = csv.join("\n");

        if (global.AndroidBridge && typeof global.AndroidBridge.saveCsvFile === "function") {
            global.AndroidBridge.saveCsvFile(filename, csvContent);
            return;
        }

        const csvFile = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
        const link = document.createElement("a");
        const url = URL.createObjectURL(csvFile);
        link.href = url;
        link.download = filename;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        setTimeout(() => URL.revokeObjectURL(url), 1000);
    }

    function bindAndroidLinks() {
        if (!global.AndroidBridge) return;

        document.querySelectorAll("a[data-template]").forEach(link => {
            link.addEventListener("click", (e) => {
                e.preventDefault();
                const tpl = link.getAttribute("data-template");
                if (tpl && global.AndroidBridge.downloadAssetTemplate) {
                    global.AndroidBridge.downloadAssetTemplate(tpl);
                }
            });
        });

        document.querySelectorAll('a[href^="https://nikshay.in"]').forEach(link => {
            link.addEventListener("click", (e) => {
                e.preventDefault();
                if (global.AndroidBridge.openPortalUrl) {
                    global.AndroidBridge.openPortalUrl(link.href);
                }
            });
        });
    }

    function checkAuthPort(onReady) {
        if (global.NikshayAuth && global.NikshayAuth.requireAuth) {
            global.NikshayAuth.requireAuth((session) => {
                showLoading(false);
                if (onReady) onReady(session);
            });
            return;
        }

        if (global.AndroidBridge || typeof chrome === "undefined" || !chrome.runtime || !chrome.runtime.connect) {
            showLoading(false);
            if (onReady) onReady();
            return;
        }

        let settled = false;
        function finish() {
            if (!settled) {
                settled = true;
                showLoading(false);
                if (onReady) onReady();
            }
        }

        function connectPort() {
            try {
                const port = chrome.runtime.connect({ name: "knockknock" });
                global.port = port;
                port.onDisconnect.addListener(() => {
                    if (!settled) {
                        finish();
                    }
                });
                port.onMessage.addListener((reply) => {
                    const msg = reply?.reply;
                    if (msg && msg !== "ok") {
                        location.href = "login.html";
                        return;
                    }
                    finish();
                });
                port.postMessage({ "class": "check" });
            } catch (e) {
                finish();
            }
        }

        connectPort();
        setTimeout(finish, 1500);
    }

    global.NikshayCommon = {
        cleanStr,
        COLLECTION_SITE_KEYS,
        getRowVal,
        parseCSVLine,
        csvToSheet,
        excelToSheet,
        parseSpreadsheetFile,
        showLoading,
        initProfileAndVersion,
        exportTableToCSV,
        bindAndroidLinks,
        checkAuthPort
    };
})(window);
