/**
 * Ni-Kshay Automation — Cryptographic Token & Authentication Engine
 * Provides tamper-proof HMAC-SHA256 signed access tokens with time expiration.
 */
(function (global) {
    const DEFAULT_SECRET_KEY = "NiKshay@Automation#2026$AdminSecretKey!";
    const TOKEN_PREFIX = "NKA1";

    // --- Standalone FIPS-180-2 SHA-256 and RFC 2104 HMAC-SHA256 ---
    function rightRotate(value, amount) {
        return (value >>> amount) | (value << (32 - amount));
    }

    const K = [
        0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5,
        0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174,
        0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc, 0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da,
        0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967,
        0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
        0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070,
        0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3,
        0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208, 0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2
    ];

    function sha256Bytes(bytes) {
        let H = [
            0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a,
            0x510e527f, 0x9b05688c, 0x1f83d9ab, 0x5be0cd19
        ];

        const bitLength = bytes.length * 8;
        const withOne = new Uint8Array(bytes.length + 1);
        withOne.set(bytes);
        withOne[bytes.length] = 0x80;

        let zeroPadLen = (64 - ((withOne.length + 8) % 64)) % 64;
        const padded = new Uint8Array(withOne.length + zeroPadLen + 8);
        padded.set(withOne);

        const view = new DataView(padded.buffer);
        view.setUint32(padded.length - 4, bitLength, false);

        const W = new Int32Array(64);
        for (let i = 0; i < padded.length; i += 64) {
            for (let t = 0; t < 16; t++) {
                W[t] = view.getInt32(i + t * 4, false);
            }
            for (let t = 16; t < 64; t++) {
                const s0 = rightRotate(W[t - 15], 7) ^ rightRotate(W[t - 15], 18) ^ (W[t - 15] >>> 3);
                const s1 = rightRotate(W[t - 2], 17) ^ rightRotate(W[t - 2], 19) ^ (W[t - 2] >>> 10);
                W[t] = (W[t - 16] + s0 + W[t - 7] + s1) | 0;
            }

            let a = H[0], b = H[1], c = H[2], d = H[3], e = H[4], f = H[5], g = H[6], h = H[7];

            for (let t = 0; t < 64; t++) {
                const S1 = rightRotate(e, 6) ^ rightRotate(e, 11) ^ rightRotate(e, 25);
                const ch = (e & f) ^ ((~e) & g);
                const temp1 = (h + S1 + ch + K[t] + W[t]) | 0;
                const S0 = rightRotate(a, 2) ^ rightRotate(a, 13) ^ rightRotate(a, 22);
                const maj = (a & b) ^ (a & c) ^ (b & c);
                const temp2 = (S0 + maj) | 0;

                h = g;
                g = f;
                f = e;
                e = (d + temp1) | 0;
                d = c;
                c = b;
                b = a;
                a = (temp1 + temp2) | 0;
            }

            H[0] = (H[0] + a) | 0;
            H[1] = (H[1] + b) | 0;
            H[2] = (H[2] + c) | 0;
            H[3] = (H[3] + d) | 0;
            H[4] = (H[4] + e) | 0;
            H[5] = (H[5] + f) | 0;
            H[6] = (H[6] + g) | 0;
            H[7] = (H[7] + h) | 0;
        }

        const out = new Uint8Array(32);
        const outView = new DataView(out.buffer);
        for (let i = 0; i < 8; i++) {
            outView.setInt32(i * 4, H[i], false);
        }
        return out;
    }

    function stringToBytes(str) {
        if (typeof TextEncoder !== "undefined") {
            return new TextEncoder().encode(str);
        }
        const utf8 = unescape(encodeURIComponent(str));
        const arr = new Uint8Array(utf8.length);
        for (let i = 0; i < utf8.length; i++) arr[i] = utf8.charCodeAt(i);
        return arr;
    }

    function bytesToHex(bytes) {
        return Array.from(bytes).map(b => b.toString(16).padStart(2, "0")).join("");
    }

    function hmacSha256Hex(keyStr, messageStr) {
        let keyBytes = stringToBytes(keyStr);
        const msgBytes = stringToBytes(messageStr);
        const blockSize = 64;

        if (keyBytes.length > blockSize) {
            keyBytes = sha256Bytes(keyBytes);
        }
        const keyPad = new Uint8Array(blockSize);
        keyPad.set(keyBytes);

        const oPad = new Uint8Array(blockSize + 32);
        const iPad = new Uint8Array(blockSize + msgBytes.length);

        for (let i = 0; i < blockSize; i++) {
            oPad[i] = keyPad[i] ^ 0x5c;
            iPad[i] = keyPad[i] ^ 0x36;
        }
        iPad.set(msgBytes, blockSize);

        const innerHash = sha256Bytes(iPad);
        oPad.set(innerHash, blockSize);

        return bytesToHex(sha256Bytes(oPad));
    }

    function hashPassword(password) {
        if (!password) return "";
        return bytesToHex(sha256Bytes(stringToBytes(password.trim())));
    }

    // Base64URL encoding/decoding
    function base64UrlEncode(str) {
        const bytes = stringToBytes(str);
        let binary = "";
        for (let i = 0; i < bytes.length; i++) {
            binary += String.fromCharCode(bytes[i]);
        }
        return btoa(binary)
            .replace(/\+/g, "-")
            .replace(/\//g, "_")
            .replace(/=+$/, "");
    }

    function base64UrlDecode(str) {
        let base64 = str.replace(/-/g, "+").replace(/_/g, "/");
        while (base64.length % 4) {
            base64 += "=";
        }
        const binary = atob(base64);
        const bytes = new Uint8Array(binary.length);
        for (let i = 0; i < binary.length; i++) {
            bytes[i] = binary.charCodeAt(i);
        }
        if (typeof TextDecoder !== "undefined") {
            return new TextDecoder().decode(bytes);
        }
        let out = "";
        for (let i = 0; i < bytes.length; i++) {
            out += String.fromCharCode(bytes[i]);
        }
        return decodeURIComponent(escape(out));
    }

    /**
     * Generate an access token for a user.
     * @param {Object} params
     * @param {string} params.username Login ID / Username
     * @param {string} [params.password] Optional user password / PIN
     * @param {number} params.expiresAt Timestamp (ms) when token expires
     * @param {string} [params.secretKey] Optional custom signing key
     * @returns {string} Signed token string
     */
    function generateToken({ username, password = "", expiresAt, secretKey = DEFAULT_SECRET_KEY }) {
        if (!username || !username.trim()) {
            throw new Error("Username / Login ID is required to generate a token.");
        }
        if (!expiresAt || expiresAt <= Date.now()) {
            throw new Error("Expiration date must be in the future.");
        }

        const normUser = username.trim().toLowerCase();
        const pinHash = password ? hashPassword(password).substring(0, 16) : "";

        const payload = {
            u: normUser,
            p: pinHash,
            exp: Math.floor(expiresAt),
            iat: Date.now(),
            v: 1
        };

        const payloadJson = JSON.stringify(payload);
        const encodedPayload = base64UrlEncode(payloadJson);
        const signature = hmacSha256Hex(secretKey, `${TOKEN_PREFIX}.${encodedPayload}`);

        return `${TOKEN_PREFIX}-${encodedPayload}-${signature}`;
    }

    /**
     * Inspect and parse a token without validating password (useful for admin verification).
     */
    function decodeToken(tokenStr) {
        try {
            if (!tokenStr || typeof tokenStr !== "string") return null;
            const clean = tokenStr.trim();
            const parts = clean.split("-");
            if (parts.length < 3 || parts[0] !== TOKEN_PREFIX) return null;

            const payloadJson = base64UrlDecode(parts[1]);
            const payload = JSON.parse(payloadJson);
            return {
                prefix: parts[0],
                encodedPayload: parts[1],
                signature: parts.slice(2).join("-"),
                payload
            };
        } catch (e) {
            return null;
        }
    }

    /**
     * Verify an access token.
     * @param {string} tokenStr The token string to verify
     * @param {string} username The login username to match against
     * @param {string} [password] Optional password
     * @param {string} [secretKey] Signing key
     * @returns {Object} { valid, expired, payload, remainingDays, expiresDate, error }
     */
    function verifyToken(tokenStr, username, password = "", secretKey = DEFAULT_SECRET_KEY) {
        if (!tokenStr || !tokenStr.trim()) {
            return { valid: false, error: "Token is empty." };
        }
        if (!username || !username.trim()) {
            return { valid: false, error: "Login ID is required." };
        }

        const decoded = decodeToken(tokenStr);
        if (!decoded || !decoded.payload) {
            return { valid: false, error: "Invalid token format." };
        }

        const { encodedPayload, signature, payload } = decoded;

        // 1. Verify cryptographic signature
        const expectedSig = hmacSha256Hex(secretKey, `${TOKEN_PREFIX}.${encodedPayload}`);
        if (signature.toLowerCase() !== expectedSig.toLowerCase()) {
            return { valid: false, error: "Invalid token signature. Token may have been altered." };
        }

        // 2. Verify username match
        const normUser = username.trim().toLowerCase();
        if (payload.u !== normUser) {
            return {
                valid: false,
                error: `Token belongs to user "${payload.u}", not "${normUser}".`
            };
        }

        // 3. Verify password match if token requires one
        if (payload.p) {
            const pinHash = hashPassword(password).substring(0, 16);
            if (pinHash !== payload.p) {
                return { valid: false, error: "Incorrect password for this token." };
            }
        }

        // 4. Verify expiration
        const now = Date.now();
        const expiresDate = new Date(payload.exp);
        const remainingMs = payload.exp - now;
        const remainingDays = Math.ceil(remainingMs / (1000 * 60 * 60 * 24));

        if (now > payload.exp) {
            return {
                valid: false,
                expired: true,
                payload,
                expiresDate,
                remainingDays: 0,
                error: `Token expired on ${expiresDate.toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "numeric", hour: "2-digit", minute: "2-digit" })}. Please request a new token from Admin.`
            };
        }

        return {
            valid: true,
            expired: false,
            payload,
            expiresDate,
            remainingDays: Math.max(1, remainingDays),
            error: null
        };
    }

    // --- Storage persistence helpers ---
    function getStorage() {
        if (typeof chrome !== "undefined" && chrome.storage && chrome.storage.sync) {
            return chrome.storage.sync;
        }
        return {
            get(keys, cb) {
                const res = {};
                (Array.isArray(keys) ? keys : [keys]).forEach(k => {
                    try { res[k] = JSON.parse(localStorage.getItem(k)); } catch (_) { res[k] = localStorage.getItem(k); }
                });
                if (cb) cb(res);
                return Promise.resolve(res);
            },
            set(items, cb) {
                Object.entries(items).forEach(([k, v]) => {
                    localStorage.setItem(k, typeof v === "object" ? JSON.stringify(v) : v);
                });
                if (cb) cb();
                return Promise.resolve();
            },
            remove(keys, cb) {
                (Array.isArray(keys) ? keys : [keys]).forEach(k => localStorage.removeItem(k));
                if (cb) cb();
                return Promise.resolve();
            }
        };
    }

    async function saveAuthSession({ username, token, password = "", expiresAt }) {
        const store = getStorage();
        const data = {
            auth_user: username.trim().toLowerCase(),
            auth_token: token.trim(),
            auth_expires: expiresAt,
            auth_pin_hash: password ? hashPassword(password).substring(0, 16) : "",
            username: username.trim() // keeps Nikshay API compatibility
        };
        await store.set(data);
    }

    async function getAuthSession() {
        const store = getStorage();
        const items = await store.get(["auth_user", "auth_token", "auth_expires", "auth_pin_hash"]);
        if (!items?.auth_token || !items?.auth_user) {
            return { isAuthenticated: false };
        }

        const decoded = decodeToken(items.auth_token);
        if (!decoded) {
            return { isAuthenticated: false, error: "Corrupted token" };
        }

        const verify = verifyToken(items.auth_token, items.auth_user, "", DEFAULT_SECRET_KEY);
        // If password is required by token
        if (!verify.valid && verify.error && verify.error.includes("Incorrect password")) {
            // Check stored pin hash
            if (decoded.payload.p && decoded.payload.p === items.auth_pin_hash) {
                const now = Date.now();
                if (now > decoded.payload.exp) {
                    return {
                        isAuthenticated: false,
                        expired: true,
                        user: items.auth_user,
                        expiresDate: new Date(decoded.payload.exp),
                        remainingDays: 0,
                        error: "Access token has expired."
                    };
                }
                return {
                    isAuthenticated: true,
                    expired: false,
                    user: items.auth_user,
                    token: items.auth_token,
                    expiresDate: new Date(decoded.payload.exp),
                    remainingDays: Math.max(1, Math.ceil((decoded.payload.exp - now) / (1000 * 60 * 60 * 24)))
                };
            }
        }

        if (!verify.valid) {
            return {
                isAuthenticated: false,
                expired: verify.expired,
                user: items.auth_user,
                expiresDate: verify.expiresDate,
                remainingDays: verify.remainingDays || 0,
                error: verify.error
            };
        }

        return {
            isAuthenticated: true,
            expired: false,
            user: items.auth_user,
            token: items.auth_token,
            expiresDate: verify.expiresDate,
            remainingDays: verify.remainingDays
        };
    }

    async function clearAuthSession() {
        const store = getStorage();
        await store.remove(["auth_user", "auth_token", "auth_expires", "auth_pin_hash"]);
    }

    /**
     * Route guard: Call at top of protected pages.
     * Redirects to login.html if token missing or expired.
     */
    async function requireAuth(onSuccess) {
        const session = await getAuthSession();
        if (!session.isAuthenticated) {
            const reason = session.expired ? "expired" : "missing";
            location.href = `login.html?reason=${reason}&user=${encodeURIComponent(session.user || "")}`;
            return;
        }

        // Token is active: inject user & remaining days badge into header
        renderHeaderBadge(session);
        if (typeof onSuccess === "function") {
            onSuccess(session);
        }
    }

    function renderHeaderBadge(session) {
        const emailEl = document.getElementById("email");
        if (!emailEl) return;

        const days = session.remainingDays;
        const color = days <= 3 ? "#ff4444" : days <= 7 ? "#ffbb33" : "#00ff7f";
        const dateStr = session.expiresDate ? session.expiresDate.toLocaleDateString("en-IN", { day: "numeric", month: "short" }) : "";

        emailEl.innerHTML = `
            <span style="display:inline-flex; align-items:center; gap:6px;">
                <span>ID: <strong>${session.user}</strong></span>
                <span style="font-size:11px; background:rgba(255,255,255,0.12); padding:2px 7px; border-radius:12px; border:1px solid ${color}; color:${color};" title="Expires ${dateStr}">
                    ⏱️ ${days}d left
                </span>
                <a href="login.html" style="color:#aaa; text-decoration:none; font-size:11px; margin-left:4px;" title="Renew Token or Switch User">⚙️</a>
            </span>
        `;
    }

    global.NikshayAuth = {
        DEFAULT_SECRET_KEY,
        hashPassword,
        generateToken,
        decodeToken,
        verifyToken,
        saveAuthSession,
        getAuthSession,
        clearAuthSession,
        requireAuth,
        renderHeaderBadge
    };
})(window);
